I used assests from the following sites:

1. player spaceship:  https://foozlecc.itch.io/void-fleet-pack-1
2. asteroids:         https://foozlecc.itch.io/void-environment-pack
